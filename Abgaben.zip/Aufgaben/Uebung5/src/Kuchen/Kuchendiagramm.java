/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Kuchen;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.PieChart.Data;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.collections.ObservableList;
import javafx.scene.Group;
import javafx.scene.control.Slider;

/**
 *
 * @author tabea
 */
public class Kuchendiagramm extends Application {

    @Override
    public void start(Stage primaryStage) {
        //Beobachter
        PieChart pieChart = new PieChart();
        pieChart.setData(getChartData());

        javafx.application.Platform.runLater(new Runnable() {

            @Override
            public void run() {
                //slider für param1 --------------------------------------------
                Slider slider = new Slider(0, 100, 50);
                slider.setShowTickLabels(true);
                slider.setShowTickMarks(true);

                Stage stage = new Stage();
                stage.setScene(new Scene(new Group(slider)));
                stage.setTitle("Param 1");
                stage.setX(primaryStage.getX() + primaryStage.getWidth());
                stage.setY(primaryStage.getY());
                stage.show();

                //Slider für param2 --------------------------------------------
                Slider slider2 = new Slider(0, 100, 50);
                slider2.setShowTickLabels(true);
                slider2.setShowTickMarks(true);

                Stage stage2 = new Stage();
                stage2.setScene(new Scene(new Group(slider2)));
                stage2.setTitle("Param 2");
                stage2.setX(primaryStage.getX() + primaryStage.getWidth());
                stage2.setY(primaryStage.getY() + primaryStage.getHeight() - stage2.getHeight());
                stage2.show();

                slider.valueProperty().addListener(new ChangeListener<Number>() {
                    @Override
                    public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                        double anteil = pieChart.getData().get(1).getPieValue() / (100 - pieChart.getData().get(0).getPieValue());

                        pieChart.getData().get(0).setPieValue((double) newValue);
                        pieChart.getData().get(1).setPieValue(
                                slider2.valueProperty().getValue()
                                //(100 - pieChart.getData().get(0).getPieValue()) * anteil
                        );
                        pieChart.getData().get(2).setPieValue(
                                (100 - pieChart.getData().get(0).getPieValue() - pieChart.getData().get(1).getPieValue())
                        );
                    }
                });

                slider2.valueProperty().addListener(new ChangeListener<Number>() {
                    @Override
                    public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                        double anteil = pieChart.getData().get(0).getPieValue() / (100 - pieChart.getData().get(1).getPieValue());

                        pieChart.getData().get(1).setPieValue((double) newValue);
                        pieChart.getData().get(0).setPieValue(
                                slider.valueProperty().getValue()
                        );
                        pieChart.getData().get(2).setPieValue(
                                (100 - pieChart.getData().get(0).getPieValue() - pieChart.getData().get(1).getPieValue())
                        );
                    }
                });

            }
        });

        StackPane root = new StackPane();
        root.getChildren().add(pieChart);
        Scene scene = new Scene(root, 300, 250);
        primaryStage.setTitle("Kuchendiagramm");
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    private ObservableList<Data> getChartData() {
        ObservableList<Data> answer = FXCollections.observableArrayList();
        answer.addAll(
                new PieChart.Data("Parameter 1", 69.00),
                new PieChart.Data("Parameter 2", 12.00));
        answer.add(
                new PieChart.Data("Parameter 3", (100 - answer.get(0).getPieValue() - answer.get(1).getPieValue())));
        return answer;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}

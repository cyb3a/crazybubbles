package ampel2;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import static javafx.application.Application.launch;

/**
 *
 * @author tabea
 */
public class autonomeAmpel extends Application implements Runnable {

    boolean terminate = false;
    Circle red = new Circle();
    Circle green = new Circle();
    Circle yellow = new Circle();
    Button btnRed = new Button("red");
    Button btnGreen = new Button("green");
    Button btnBlink = new Button("blink");
    Rectangle rectangle = new Rectangle();
    AnimationTimer timer;
    Thread t = new Thread(this);
    Thread threadRed;
    Thread threadGreen;
    Thread threadBlink;

    //Thread Klassen
    @Override
    public void start(Stage primaryStage) {
        generatetrafficLight(primaryStage);
        System.out.println("Oberflaeche generiert");

        t.start();

    }

    public void green() {
        if (timer != null) {
            timer.stop();
        }
        red.setFill(Color.BLACK);
        green.setFill(Color.GREEN);
        yellow.setFill(Color.BLACK);

    }

    public void red() {
        if (timer != null) {
            timer.stop();
        }
        red.setFill(Color.RED);
        green.setFill(Color.BLACK);
        yellow.setFill(Color.BLACK);
    }

    public void redyellow() {
        if (timer != null) {
            timer.stop();
        }
        red.setFill(Color.RED);
        green.setFill(Color.BLACK);
        yellow.setFill(Color.YELLOW);

    }

    public void blink() {
        timer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                green.setFill(Color.BLACK);
                red.setFill(Color.BLACK);
                if (yellow.getFill().equals(Color.YELLOW)) {
                    yellow.setFill(Color.BLACK);
                } else {
                    yellow.setFill(Color.YELLOW);
                }
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                }
            }
        };
        timer.start();
    }

    public void generatetrafficLight(Stage pStage) {

        //grid layout
        GridPane grid = new GridPane();
        grid.setHgap(20);
        grid.setVgap(5);

        //buttons
        HBox hbButtons = new HBox();
        btnRed.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                red(); //TODO evtl hier aendern
            }
        });
        btnGreen.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                green();
            }
        });
        btnBlink.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                blink();
            }
        });
        hbButtons.getChildren().addAll(btnRed, btnGreen, btnBlink);

        //Ampelform
        rectangle.setX(150);
        rectangle.setY(75);
        rectangle.setWidth(400);
        rectangle.setHeight(200);
        rectangle.setFill(Color.BLACK);

        //Lichter
        green.setCenterX(230);
        green.setCenterY(170);
        green.setRadius(50);
        green.setFill(Color.GREEN);
        yellow.setCenterX(345);
        yellow.setCenterY(170);
        yellow.setRadius(50);
        yellow.setFill(Color.YELLOW);
        red.setCenterX(465);
        red.setCenterY(170);
        red.setRadius(50);
        red.setFill(Color.RED);

        StackPane root = new StackPane();
        Pane p1 = new Pane(red, green, yellow);
        Pane p2 = new Pane(rectangle);

        hbButtons.setPadding(new Insets(15, 12, 15, 12));
        hbButtons.setSpacing(10);   // Gap between nodes

        grid.add(hbButtons, 2, 2, 2, 1);
        root.getChildren().addAll(p2, p1, grid);
        Scene scene = new Scene(root, 700, 500);

        pStage.setTitle("Ampel (automatisch)");
        pStage.setScene(scene);
        pStage.show();

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void run() {
        while (!terminate) {

            //TODO if bedingungen, wann wie geschaltet werden soll
            
            setRedThreaded();
            setGreenThreaded();

        }
    }

    private void setRedThreaded() {
        threadRed = new Thread(new ThreadRed());
        threadRed.start();
        System.out.println("ThreadRed gestartet");
        synchronized (threadRed) {
            try {
                threadRed.wait();
            } catch (InterruptedException e) {
            }
        }
    }

    private void setGreenThreaded() {
        threadGreen = new Thread(new ThreadGreen());
        threadGreen.start();
        System.out.println("ThreadGreen gestartet");
        synchronized (threadGreen) {
            try {
                threadGreen.wait();
            } catch (InterruptedException e) {
            }
        }
    }

    private class ThreadRed implements Runnable {

        @Override
        public void run() {
            synchronized (this) {
                red();
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                }
                notify();
            }
        }
    };

    private class ThreadGreen implements Runnable {

        @Override
        public void run() {
            synchronized (this) {
                redyellow();
                try {
                    //zeige rot-gelb fuer 2 Sekunden an
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                green();
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                notify();
            }
        }
    };

    private class ThreadBlink implements Runnable {

        @Override
        public void run() {
            synchronized (this) {
                blink();
            }
        }
    };

    @Override
    public void stop() {
        System.out.println("Stage is closing");
        terminate = true;
        t.interrupt();
        threadRed.interrupt();
        threadGreen.interrupt();

    }
}

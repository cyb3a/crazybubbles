
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javafx.animation.AnimationTimer;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Ellipse;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * Spiel Arkanoid, 1 Level,
 *
 * @author s0558439
 */
public class Arkanoid extends Application {

    final List<ObstacleBrick> obstacles = new ArrayList<>();
    final int amountObstacles = 84;
    final Rectangle paddle = new Rectangle(100, 10);
    final MovingEllipse ball = new MovingEllipse(new Ellipse(10, 10), 3, 3);
    private Group group = new Group();  //root node for the play window
    private final Random random = new Random();
    private boolean timerIsRunning = false;

    @Override
    public void start(Stage primaryStage) {
        final BorderPane borderPane;
        final Scene scene;
        final Pane pane;
        primaryStage.setTitle("ARKANOID");
        pane = new Pane(group);
        pane.setPrefSize(800, 600);
        pane.setStyle("-fx-background-color: #772953;");

        borderPane = new BorderPane();
        borderPane.setCenter(pane);
        scene = new Scene(borderPane, 800, 600, Color.ANTIQUEWHITE);
        generatePlayGround(pane);

        AnimationTimer timer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                ObstacleBrick rectToDelete = null;

                Double ballPositionYOben = ball.getEllipse().getCenterY() - ball.getEllipse().getRadiusY();
                Double ballPositionYUnten = ball.getEllipse().getCenterY() + ball.getEllipse().getRadiusY();

                Double ballPositionXLinks = ball.getEllipse().getCenterX() - ball.getEllipse().getRadiusX();
                Double ballPositionXRechts = ball.getEllipse().getCenterX() + ball.getEllipse().getRadiusX();

                for (ObstacleBrick rect : obstacles) {

                    Double rectanglePositionYOben = rect.getRectangle().getY();
                    Double rectanglePositionYUnten = rect.getRectangle().getY() + rect.getRectangle().getHeight();

                    Double rectanglePositionXLinks = rect.getRectangle().getX();
                    Double rectanglePositionXRechts = rect.getRectangle().getX() + rect.getRectangle().getWidth();

                    //oben oder unten
                    if (ball.getEllipse().getCenterX() <= rectanglePositionXRechts && ball.getEllipse().getCenterX() > rectanglePositionXLinks) {

                        //trifft unterseite
                        if (ballPositionYOben <= rectanglePositionYUnten && ball.getEllipse().getCenterY() >= (rect.getRectangle().getY() + rect.getRectangle().getHeight() / 2)) {

                            ball.setStepY(-ball.getStepY());

                            if (rect.getLifeCounter() > 0) {
                                rect.setLifeCounter(rect.getLifeCounter() - 1);
                                rect.getRectangle().setOpacity(rect.getRectangle().getOpacity() / 2);
                            } else {
                                group.getChildren().remove(rect.getRectangle());
                                rectToDelete = rect;
                            }
                        } //trifft oberseite
                        else if (ballPositionYUnten >= rectanglePositionYOben && ball.getEllipse().getCenterY() < rect.getRectangle().getY()) {

                            ball.setStepY(-ball.getStepY());

                            if (rect.getLifeCounter() > 0) {
                                rect.setLifeCounter(rect.getLifeCounter() - 1);
                                rect.getRectangle().setOpacity(rect.getRectangle().getOpacity() / 2);
                            } else {
                                group.getChildren().remove(rect.getRectangle());
                                rectToDelete = rect;
                            }
                        }
                    } //von der seite treffen
                    //else if (ball.getEllipse().getCenterY() <= rectanglePositionYUnten && ball.getEllipse().getCenterY() >= rectanglePositionYOben) {
                    else if (ballPositionYOben <= rectanglePositionYUnten && ballPositionYUnten >= rectanglePositionYOben) {
                        //trifft rechts
                        if ((ballPositionXLinks <= rectanglePositionXRechts) && ballPositionXLinks > (rectanglePositionXRechts)) {

                            ball.setStepX(-ball.getStepX());

                            if (rect.getLifeCounter() > 0) {
                                rect.setLifeCounter(rect.getLifeCounter() - 1);
                                rect.getRectangle().setOpacity(rect.getRectangle().getOpacity() / 2);
                            } else {
                                group.getChildren().remove(rect.getRectangle());
                                rectToDelete = rect;
                            }
                        }

                        //trifft links
                        if ((ballPositionXLinks >= rectanglePositionXLinks) && ballPositionXLinks < (rectanglePositionXLinks)) {

                            ball.setStepX(-ball.getStepX());

                            if (rect.getLifeCounter() > 0) {
                                rect.setLifeCounter(rect.getLifeCounter() - 1);
                                rect.getRectangle().setOpacity(rect.getRectangle().getOpacity() / 2);
                            } else {
                                group.getChildren().remove(rect.getRectangle());
                                rectToDelete = rect;
                            }
                        }
                    }

                }
                if (obstacles.isEmpty()) {
                    Alert alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Information Dialog");
                    alert.setHeaderText("GAME OVER");
                    alert.setContentText("GEWONNEN!");
                    stop();
                    timerIsRunning = false;
                    alert.show();
                }
                obstacles.remove(rectToDelete);

                //rechter Rand
                if (ballPositionXRechts > pane.getWidth() && ball.getStepX() > 0) {
                    ball.setStepX(-ball.getStepX());
                }

                //linker Rand
                if (ballPositionXLinks < 0) {
                    ball.setStepX(-ball.getStepX());
                }

                //unterer Rand
                if (ballPositionYUnten > pane.getHeight()) {
                    //ball.setStepY(-ball.getStepY());
                    Alert alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Information Dialog");
                    alert.setHeaderText("GAME OVER");
                    alert.setContentText("YOU LOST!");
                    stop();
                    timerIsRunning = false;
                    alert.show();

                }

                //oberer Rand
                if (ballPositionYOben < 0) {
                    ball.setStepY(-ball.getStepY());
                }

                //paddle
                if (ballPositionYUnten > paddle.getY()
                        && ball.getStepY() > 0
                        && ball.getEllipse().getCenterX() < paddle.getX() + paddle.getWidth()
                        && paddle.getX() < ball.getEllipse().getCenterX()) {

                    ball.setStepY(-ball.getStepY());

                    //abstosswinkel
                    //linker rand vom paddle
                    if (ballPositionXRechts < paddle.getX() + (paddle.getWidth() * 0.4)) {
                        if (ball.getStepX() > 0) {
                            ball.setStepX(-ball.getStepX());
                        }

                    }
                    //rechter rand vom paddle
                    if (ballPositionXLinks > paddle.getX() + (paddle.getWidth() * 0.7)) {
                        if (ball.getStepX() < 0) {
                            ball.setStepX(-ball.getStepX());
                        }
                    }
                }

                //bewegen
                ball.getEllipse().setCenterX(ball.getEllipse().getCenterX() + ball.getStepX());
                ball.getEllipse().setCenterY(ball.getEllipse().getCenterY() + ball.getStepY());

                try {
                    Thread.sleep(10);
                } catch (InterruptedException e) {
                }
            }
        };

        //TODO evtl rausnehmen
        scene.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent event) {
                switch (event.getCode()) {
                    case RIGHT:
                        if (paddle.getX() < pane.getWidth() - paddle.getWidth()) {
                            paddle.setX(paddle.getX() + 10);
                        }
                        break;
                    case LEFT:
                        if (paddle.getX() > 0) {
                            paddle.setX(paddle.getX() - 10);
                        }
                        break;
                    case SPACE:
                        if (timerIsRunning) {
                            timer.stop();
                            timerIsRunning = false;
                        } else {
                            timer.start();
                            timerIsRunning = true;
                        }
                        break;
                }
            }
        });

        scene.setOnMouseMoved(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                //TODO winkel
                if (event.getSceneX() > paddle.getX()) {
                    if (paddle.getX() < pane.getWidth() - paddle.getWidth()) {
                        paddle.setX(paddle.getX() + 10);
                    }
                }

                if (event.getSceneX() < paddle.getX()) {
                    if (paddle.getX() > 0) {
                        paddle.setX(paddle.getX() - 10);
                    }
                }
            }
        });

        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();

    }

    public void generatePlayGround(Pane p) {

        // Obstacles hinzufuegen
        int positionX = 10;
        int positionY = 30;

        //random Positionen fuer Menge an Bricks mit mehreren Leben generieren
        List<Integer> specialBrickPositions = new ArrayList<>(amountObstacles/4);
        while (specialBrickPositions.size() < amountObstacles/4) {
            specialBrickPositions.add(random.nextInt(amountObstacles - 1));
        }

        for (int i = 0; i < amountObstacles; i++) {
            Rectangle localRectangle = new Rectangle(positionX, positionY, 50, 20);
            // localRectangle.setFill(new Color(random.nextFloat(), random.nextFloat(), random.nextFloat(), 0.9));
            localRectangle.setFill(Color.web("#E95420"));
            localRectangle.setStrokeWidth(2);
            localRectangle.setStroke(Color.web("#5E2750"));
            localRectangle.setArcHeight(10);
            localRectangle.setArcWidth(10);

            //standardmaessig 0 (1 Aufprall -> Tod)
            ObstacleBrick localObstacleBrick = new ObstacleBrick(localRectangle, 0);

            //special brick mit 3 Leben anlegen
            if (specialBrickPositions.contains(i)) {
                localObstacleBrick.setLifeCounter(2);
                localObstacleBrick.getRectangle().setFill(Color.web("#2C001E"));
                localObstacleBrick.getRectangle().setStroke(Color.web("#AEA79F"));
            }

            obstacles.add(localObstacleBrick);
            group.getChildren().add(localObstacleBrick.getRectangle());

            positionX += localRectangle.getWidth() + 5;
            if (positionX + localRectangle.getWidth() > p.getPrefWidth()) {
                positionY += localRectangle.getHeight() * 3;
                positionX = 10;
            }
        }

        //paddle hinzufuegen
        paddle.setArcWidth(20);
        paddle.setArcHeight(20);
        paddle.setX((p.getScene().getWidth() / 2) - (paddle.getWidth() / 2));
        paddle.setY(p.getScene().getHeight() - p.getScene().getHeight() * 0.1);
        group.getChildren().add(paddle);

        //ball hinzufuegen
        ball.getEllipse().setCenterX(paddle.getX() + paddle.getWidth() / 2);
        ball.getEllipse().setCenterY(paddle.getY()-(ball.getEllipse().getRadiusY()));
        ball.getEllipse().setFill(Color.WHITE);
        group.getChildren().add(ball.getEllipse());
    }

    public static void main(String[] args) {
        Application.launch(args);
    }

    private class MovingEllipse {

        private double stepX; //
        private double stepY;
        private Ellipse c; //reference on a circle

        MovingEllipse(Ellipse c, double dx, double dy) {
            this.c = c;
            stepX = dx;
            stepY = dy;
        }

        public double getStepX() {
            return stepX;
        }

        public void setStepX(double stepX) {
            this.stepX = stepX;
        }

        public double getStepY() {
            return stepY;
        }

        public void setStepY(double stepY) {
            this.stepY = stepY;
        }

        public Ellipse getEllipse() {
            return c;
        }

        public void setEllipse(Ellipse c) {
            this.c = c;
        }
    }

    private class ObstacleBrick {

        private Rectangle r;
        private int lifeCounter;

        public ObstacleBrick() {
            this.r = null;
            this.lifeCounter = 0;
        }

        public ObstacleBrick(Rectangle r, int lifeCounter) {
            this.r = r;
            this.lifeCounter = lifeCounter;
        }

        public Rectangle getRectangle() {
            return r;
        }

        public void setRectangle(Rectangle r) {
            this.r = r;
        }

        public int getLifeCounter() {
            return lifeCounter;
        }

        public void setLifeCounter(int lifeCounter) {
            this.lifeCounter = lifeCounter;
        }

    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uebung2;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

/**
 *
 * @author s0558439
 */
public class Uebung2 extends Application {

    int foundIndex = 0;

    public void setFoundIndex(int i) {
        foundIndex = i;
    }

    @Override
    public void start(Stage primaryStage) {
        BorderPane borderPane = new BorderPane();
        TextArea textArea = new TextArea();
        TextField searchBox = new TextField();
        TextField replaceBox = new TextField();
        Button searchBtn = new Button("Suche");
        Button searchReplaceBtn = new Button("Ersetze");
        Label upperLowerCaseCBlbl = new Label("Groß/Kleinschreibung beachten:");
        CheckBox upperLowerCaseCB = new CheckBox();

        final KeyCombination keyCombinationSearch = new KeyCodeCombination(KeyCode.S, KeyCombination.CONTROL_DOWN);
        final KeyCombination keyCombinationReplace = new KeyCodeCombination(KeyCode.F, KeyCombination.CONTROL_DOWN);

        textArea.setWrapText(true);

        searchBtn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                String tmpText = textArea.getText();
                String searchText = searchBox.getText();

                //groß-, kleinschreibung ignorieren
                if (!upperLowerCaseCB.isSelected()) {
                    tmpText = tmpText.toLowerCase();
                    searchText = searchText.toLowerCase();
                }
                //ansonsten arbeite mit normalem Text weiter...

                if (tmpText.contains(searchText)) {
                    textArea.selectRange(tmpText.indexOf(searchText, foundIndex), tmpText.indexOf(searchText, foundIndex) + searchText.length());
                    setFoundIndex(tmpText.indexOf(searchText, foundIndex) + searchText.length());
                }
            }
        }
        );

        searchReplaceBtn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                String tmpText = textArea.getText();
                String searchText = searchBox.getText();
                String replaceText = replaceBox.getText();

                textArea.getSelection().getStart();
                textArea.setText(tmpText.replace(searchText, replaceText));

                borderPane.getChildren().remove(borderPane.lookup("#replacehbox"));
            }
        });

        final MenuBar menuBar = new MenuBar();

        Menu menuFile = new Menu("Datei");
        Menu menuEdit = new Menu("Bearbeiten");
        menuBar.getMenus().addAll(menuFile, menuEdit);
        MenuItem menuItem1 = new MenuItem("Neu");
        MenuItem menuItem2 = new MenuItem("Öffnen");
        MenuItem menuItem3 = new MenuItem("Speichern unter...");
        MenuItem menuItem4 = new MenuItem("Programm beenden");

        menuFile.getItems().addAll(menuItem1, menuItem2, menuItem3, menuItem4);

        MenuItem menuItem5 = new MenuItem("Suchen");
        MenuItem menuItem6 = new MenuItem("Ersetzen");

        menuItem5.setAccelerator(keyCombinationSearch);
        menuItem5.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                HBox hboxSearch = new HBox(5);
                hboxSearch.getChildren().addAll(searchBox, upperLowerCaseCBlbl, upperLowerCaseCB, searchBtn);
                borderPane.setBottom(hboxSearch);
            }
        });

        menuItem6.setAccelerator(keyCombinationReplace);
        menuItem6.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                HBox hboxSearch = new HBox(2);
                hboxSearch.getChildren().addAll(new Label("suche:"), searchBox, new Label("ersetze:"), replaceBox, searchReplaceBtn);
                borderPane.setBottom(hboxSearch);
                hboxSearch.setId("replacehbox");
            }
        });

        menuEdit.getItems().addAll(menuItem5, menuItem6);

        borderPane.setTop(menuBar);
        borderPane.setCenter(textArea);

        Scene scene = new Scene(borderPane, 700, 650);
        primaryStage.setTitle("Aufgabe1!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}

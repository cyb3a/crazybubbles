/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uebung2;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.IndexRange;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

/**
 *
 * @author corinna
 */
public class MyTexteditor extends Application {

    int foundIndex = 0;

    public void setFoundIndex(int i) {
        foundIndex = i;
    }

    @Override
    public void start(Stage primaryStage) {
        BorderPane borderPane = new BorderPane();
        TextArea textArea = new TextArea();
        TextField searchBox = new TextField();
        TextField replaceBox = new TextField();
        Button searchBtn = new Button("Suche");
        Button replaceBtn = new Button("Ersetze");
        Label upperLowerCaseCBlbl = new Label("Groß/Kleinschreibung beachten:");
        CheckBox upperLowerCaseCB = new CheckBox();

        final KeyCombination keyCombinationSearch = new KeyCodeCombination(KeyCode.S, KeyCombination.CONTROL_DOWN);
        final KeyCombination keyCombinationReplace = new KeyCodeCombination(KeyCode.E, KeyCombination.CONTROL_DOWN);

        textArea.setWrapText(true);

        searchBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                String tmpText = textArea.getText();
                String searchText = searchBox.getText();

                //groß-, kleinschreibung ignorieren
                if (!upperLowerCaseCB.isSelected()) {
                    tmpText = tmpText.toLowerCase();
                    searchText = searchText.toLowerCase();
                }
                //ansonsten arbeite mit normalem Text weiter...

                if (tmpText.contains(searchText)) {
                    textArea.selectRange(tmpText.indexOf(searchText, foundIndex), tmpText.indexOf(searchText, foundIndex) + searchText.length());

                    //Ende vom abgesuchten bereich weiter setzen
                    //setze den found-Index wieder auf 0, wenn das wort am ende nicht mehr vorkommt
                    if (!tmpText.substring(tmpText.indexOf(searchText, foundIndex) + searchText.length(), tmpText.length()).contains(searchText)) {
                        setFoundIndex(0);
                    } else {
                        setFoundIndex(tmpText.indexOf(searchText, foundIndex) + searchText.length());
                    }
                }
                else{
                    //wenn nichts gefunden, nichts auswählen
                    textArea.selectRange(0, 0);
                }
            }
        });

        replaceBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                //textArea.getSelectedText();
                IndexRange selection = textArea.getSelection();
                int startIndex = selection.getStart();
                int endIndex = selection.getEnd();
                String pre = textArea.getText().substring(0, startIndex);
                String after = textArea.getText().substring(endIndex, textArea.getText().length());
                if (searchBox.getText().equals(textArea.getSelectedText())) {
                    //ersetzen von stardindex bis endindex
                    textArea.setText(pre + replaceBox.getText() + after);
                }
            }
        });

        //Menu----------------------------------------------------
        final MenuBar menuBar = new MenuBar();

        Menu menuFile = new Menu("Datei");
        Menu menuEdit = new Menu("Bearbeiten");
        menuBar.getMenus().addAll(menuFile, menuEdit);
        MenuItem menuItem1 = new MenuItem("Neu");
        MenuItem menuItem2 = new MenuItem("Öffnen");
        MenuItem menuItem3 = new MenuItem("Speichern unter...");
        MenuItem menuItem4 = new MenuItem("Programm beenden");
        menuFile.getItems().addAll(menuItem1, menuItem2, menuItem3, menuItem4);
        MenuItem menuItem5 = new MenuItem("Suchen");
        MenuItem menuItem6 = new MenuItem("Ersetzen");
        menuItem5.setAccelerator(keyCombinationSearch);
        menuItem5.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                HBox hboxSearch = new HBox(2);
                hboxSearch.getChildren().addAll(new Label("Suche:"), searchBox, searchBtn,
                        upperLowerCaseCBlbl, upperLowerCaseCB);
                borderPane.setBottom(hboxSearch);
            }
        });

        menuItem6.setAccelerator(keyCombinationReplace);
        menuItem6.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                HBox hboxSearch = new HBox(2);
                hboxSearch.getChildren().addAll(new Label("Suche:"), searchBox, searchBtn,
                        upperLowerCaseCBlbl, upperLowerCaseCB,
                        replaceBox, replaceBtn);
                borderPane.setBottom(hboxSearch);
            }
        });
        menuEdit.getItems().addAll(menuItem5, menuItem6);
        //--------------------------------------------------------

        borderPane.setTop(menuBar);
        borderPane.setCenter(textArea);

        Scene scene = new Scene(borderPane, 1000, 650);
        primaryStage.setTitle("Texteditor");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}

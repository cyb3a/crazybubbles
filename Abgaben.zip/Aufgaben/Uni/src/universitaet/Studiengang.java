/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package universitaet;

/**
 *
 * @author tabea
 */
public enum Studiengang {
    AI("Angewandte Informatik"),
    FIW("Wirtschaft und Informatik"),
    IMI("Internationale Medieninformatik"),
    WI("Wirtschaftsinformatik");

    private String bezeichnung;

    Studiengang(String bezeichnung) {
        this.bezeichnung = bezeichnung;
    }

    public String getBezeichnung() {
        return this.bezeichnung;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package universitaet;

import Prog1Tools.IOTools;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author tabea
 */
public class StudentConsole {

    public static void main(String[] args) {
        ArrayList<Student> studierende = new ArrayList<Student>();

        ArrayList<Fach> alleFaecher = new ArrayList<Fach>();
        alleFaecher.add(new Fach(1, "Netzwerke", Studiengang.AI));
        alleFaecher.add(new Fach(2, "Betriebssysteme", Studiengang.AI));
        alleFaecher.add(new Fach(3, "Programmieren3", Studiengang.AI));
        alleFaecher.add(new Fach(3, "Projektmanagement", Studiengang.IMI));
        alleFaecher.add(new Fach(3, "Rechtliche Grundlagen", Studiengang.FIW));

        for (int i = 0; i < 3; i++) {
            System.out.println("Neue(n) Student(in) eintragen==========");
            System.out.println("Vorname:");
            String tmpVorname = IOTools.readString();
            System.out.println("Nachname:");
            String tmpNachname = IOTools.readString();
            System.out.println("Geburtsdatum(tt-mm-yyyy):");
            String tmpDatum = IOTools.readString();
            while (tmpDatum.length()!= 10 || tmpDatum.charAt(2) != '-' || tmpDatum.charAt(5) != '-'){
                tmpDatum = IOTools.readString("falsches Datumsformat(tt-mm-yyyy)");
            }
            System.out.println("Matrikelnummer:");
            String tmpMatNr = IOTools.readString();
            System.out.println("Seminargruppe(Nummer):");
            int tmpSemGrp = IOTools.readInteger();
            System.out.println("Faecher auswaehlen (bis zu 4 Stueck):");
            ArrayList<Fach> tmpFaecher = new ArrayList<Fach>();
            int fachWahl = -1;
            int count = 0;
            do {
                System.out.println("Fach " + (count + 1) + " auswaehlen:");
                for (int j = 0; j < alleFaecher.size(); j++) {
                    System.out.println("(" + j + ") " + alleFaecher.get(j).getKursName() + " (Semester " + alleFaecher.get(j).getSemester() + ", " + alleFaecher.get(j).getStudiengang() + ")");
                }
                System.out.println("(-1) -abbrechen-");
                fachWahl = IOTools.readInteger("Fachwahl:");
                if (fachWahl > -1 && fachWahl < alleFaecher.size()) {

                    }
                tmpFaecher.add(new Fach(alleFaecher.get(fachWahl)));
                count++;
            } while (fachWahl > -1 && count < 4);

            studierende.add(new Student(tmpMatNr, tmpSemGrp, tmpFaecher, tmpVorname, tmpNachname, tmpDatum));
        }

        System.out.println("\n=====Angelegte Studierende=======");
        for (Student s : studierende) {
            System.out.println(s);
        }

        int tmpFachWahl = -1;
        do {
            for (int j = 0; j < alleFaecher.size(); j++) {
                System.out.println("(" + j + ") " + alleFaecher.get(j).getKursName() + " (Semester " + alleFaecher.get(j).getSemester() + ", " + alleFaecher.get(j).getStudiengang() + ")");
            }
            System.out.print("Fachwahl (Nr.): ");
            tmpFachWahl = IOTools.readInteger();
            if (tmpFachWahl > -1 && tmpFachWahl < alleFaecher.size()) {
                System.out.println("\nStudierende in diesem Fach:");
                for (Student s : studierende) {
                    for (Fach f : s.faecher) {
                        if (f != null) {
                            if (f.getKursName().equals(alleFaecher.get(tmpFachWahl).getKursName())) {
                                System.out.println(s);
                            }
                        }
                    }
                }
            }
            System.out.println();

        } while (tmpFachWahl > -1);

    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package universitaet;

/**
 *
 * @author tabea
 */
public class Fach {

    private int semester;
    private String kursName;
    private Studiengang studiengang;

    public Fach() {
        semester = 0;
        kursName = "";
        studiengang = null;
    }

    public Fach(int semester, String kursName, Studiengang studiengang) {
        this.semester = semester;
        this.kursName = kursName;
        this.studiengang = studiengang;
    }

    public Fach(Fach f) {
        this.kursName = f.kursName;
        this.semester = f.semester;
        this.studiengang = f.studiengang;
    }

    public String getKursName() {
        return kursName;
    }

    public void setKursName(String kursName) {
        this.kursName = kursName;
    }

    public Studiengang getStudiengang() {
        return studiengang;
    }

    public void setStudiengang(Studiengang studiengang) {
        this.studiengang = studiengang;
    }
    
    public int getSemester(){
        return this.semester;
    }

    public void setSemester(int s) {
        if (s > 0 && s <= 6) {
            this.semester = s;
        } else {
            throw new IllegalArgumentException();
        }
    }

    @Override
    public String toString() {
        return "Fach{" + "semester=" + semester + ", kursName=" + kursName + ", studiengang=" + studiengang + '}';
    }
    
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package universitaet;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

/**
 *
 * @author tabea
 */
public class Student extends Person {

    private String matNr;
    private int seminargruppe;
    ArrayList<Fach> faecher = new ArrayList<Fach>();
    
    public Student(){
        super(null, null, null);
        this.matNr = null;
        this.seminargruppe = -1;
        this.faecher = null;
    }
    
    public Student(String matNr, int seminargruppe, ArrayList<Fach> faecher, String vorname, String nachname, String geburtsdatum) {
        super(vorname, nachname, geburtsdatum);
        this.matNr = matNr;
        this.seminargruppe = seminargruppe;
        this.faecher = faecher;
    }

    public String getMatNr() {
        return matNr;
    }

    public int getSeminargruppe() {
        return seminargruppe;
    }

    public ArrayList<Fach> getFaecher() {
        return faecher;
    }
    
    public String faecherToString(){
        String tmp = "";
        for (int i = 0; i < faecher.size(); i++){
            tmp = tmp + faecher.get(i).toString();
        }
        return tmp;
    }

    public void setMatNr(String matNr) {
        this.matNr = matNr;
    }

    public void setSeminargruppe(int seminargruppe) {
        this.seminargruppe = seminargruppe;
    }

    public void setFaecher(ArrayList<Fach> faecher) {
        this.faecher = faecher;
    }

    @Override
    public String toString() {
        return "Student{" + "vorname=" + this.getVorname() + ", nachname=" + this.getNachname() + ", geburtsdatum=" + this.getGeburtsdatum() + " \nmatNr=" + matNr + ", seminargruppe=" + seminargruppe + ", faecher=" + this.faecherToString() + '}';
    }

}

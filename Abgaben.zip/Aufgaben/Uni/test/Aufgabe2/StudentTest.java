/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aufgabe2;

import universitaet.Student;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author corinna
 */
public class StudentTest {
    
    public StudentTest() {
    }

    /**
     * Test of setMatNr method, of class Student.
     */
    @Test
    public void testSetAndGetMatNr() {
        System.out.println("setMatNr");
        String matNr = "558439";
        Student instance = new Student();
        instance.setMatNr(matNr);
        assertEquals(instance.getMatNr(), matNr);
    }

    
}

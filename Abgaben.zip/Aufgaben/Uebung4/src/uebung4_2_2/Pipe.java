/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uebung4_2_2;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;

/**
 *
 * @author corinna
 */
public class Pipe {
    private DataOutputStream out;
    private DataInputStream in;
    
    public Pipe() throws IOException{
        PipedOutputStream src = new PipedOutputStream();
        PipedInputStream snk = new PipedInputStream();   
        src.connect(snk);
        
        out = new DataOutputStream(src);
        in = new DataInputStream(snk);
    }
    
    public void put(int val) throws IOException{
        out.writeInt(val);
    }
    
    public int get() throws IOException {
        return in.readInt();
    }
    
    public void close() throws IOException {
        in.close();
    }
    
    public static void main(String[] args) throws IOException{
        Pipe pipe = new Pipe();
        Producer producer = new Producer(pipe);
        Consumer consumer = new Consumer(pipe);
        
        producer.start();
        consumer.start();
    }
    
    
}

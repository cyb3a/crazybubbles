/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uebung4_2_2;

import java.io.IOException;
import java.util.Random;
import java.util.Scanner;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author s0558439
 */
public class Producer extends Thread {

    final int MAX = 5;
    Random random = new Random();
    Pipe pipe;
    Scanner scanner;

    public Producer(Pipe p) {
        this.pipe = p;
        scanner = new Scanner(System.in);
    }

    public void run() {
        //erzeuge zufallswert und schiebe ihn ins Lager
        //for (int i = 0; i < MAX; i++) {
        while (true) {
            //TODO über tastatureingabe unterbrechbar machen

            int rndWert = random.nextInt(60);
            try {
                pipe.put(rndWert);
                System.out.println("Produzent: "+rndWert);
                Thread.sleep(1000 + random.nextInt(2000));
            } catch (IOException ex) {
            } catch (InterruptedException ex) {
                System.err.println(ex);
            }

        }
    }

}

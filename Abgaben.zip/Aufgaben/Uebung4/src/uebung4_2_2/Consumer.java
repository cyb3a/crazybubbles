/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uebung4_2_2;

import java.io.IOException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author s0558439
 */
public class Consumer extends Thread {

    Pipe pipe;

    public Consumer(Pipe p) {
        this.pipe = p;
    }

    public void run() {

        try {
            //producer soll die chance haben, zuerst zu laufen

            //rufe dauernd content aus dem lager ab
            while (true) {

                int value = pipe.get();
                String s = "";
                for (int i = 0; i < value; i++) {
                    s += "*";
                }
                System.out.println(s);
                System.out.println("\tKonsument: " + value);
                Thread.sleep(5000);

            }
        } catch (InterruptedException ex) {
            System.err.println(ex);
        } catch (IOException ex) {
            System.err.println(ex);
        }

    }

}

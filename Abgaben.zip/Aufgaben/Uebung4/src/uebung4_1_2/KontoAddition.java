/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uebung4_1_2;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author s0558439
 */
public class KontoAddition {

    static int addCounter = 0;

    public static void main(String[] args) {
        Konto konto = new Konto();
        int anzThreads = 5;
        //List<EinzahlThread> threads = new ArrayList<EinzahlThread>(anzThreads);
        ThreadGroup tgroup = new ThreadGroup("eine threadgroup");
        final Lock lock = new ReentrantLock();
        Random random = new Random();
        Thread[] threads = new Thread[anzThreads];


        /*
        for (int i = 0; i < anzThreads; i++) {
            threads.add(new EinzahlThread(konto, lock, tgroup));
            threads.get(i).start();
            try {
                threads.get(i).join();
            } catch (InterruptedException ex) {
            }
        }
         */
        Runnable r = new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 10; i++) {
                    int wert = random.nextInt(10);
                    
                    lock.lock();
                   
                    konto.setKontostand(konto.getKontostand() + wert);
                    addCounter++;

                    lock.unlock();
                }
            }

        };

        for (int i = 0; i < anzThreads; i++) {
            threads[i] = new Thread(r);
            threads[i].start();
            try {
                threads[i].join();
            } catch (InterruptedException ex) {
            }
        }

        System.out.println("Finaler Kontostand: " + konto.getKontostand());
        System.out.println("Anzahl Additionen: "+addCounter);

    }

}

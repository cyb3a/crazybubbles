/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uebung4_1_2;

import java.util.Random;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 *
 * @author s0558439
 */
public class EinzahlThread extends Thread {

    private Konto k;
    Random random = new Random();
    Lock lock;

    public EinzahlThread(Konto _k, Lock _l, ThreadGroup tgroup) {
        super(tgroup, "");
        this.k = _k;
        this.lock = _l;
    }

    public void run() {
        for (int i = 0; i < 20; i++) {
          //  synchronized (EinzahlThread.this) {
          lock.lock();
          try{
                System.out.println("addiere "+k.getKontostand());
                k.setKontostand(random.nextInt(10));
                //System.out.println(k.getKontostand());}
          } catch (Exception e){
              
          }
          finally {
              lock.unlock();
          }
           // }
        }
    }
}

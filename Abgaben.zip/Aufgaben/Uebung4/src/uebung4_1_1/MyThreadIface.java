/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uebung4_1_1;

/**
 *
 * @author s0558439
 */
public class MyThreadIface implements Runnable {

    @Override
    public void run() {
        while (true) {
            if (Thread.interrupted()) {
                break;
            }
           // System.out.println("HIP");
            System.out.println("\t\t\t"+Thread.currentThread().getName()+": HIP, Priorität: "+Thread.currentThread().getPriority());
            
            try {
                Thread.sleep(13);
            } catch (InterruptedException ex) {
                break;
            }
        }
    }

}

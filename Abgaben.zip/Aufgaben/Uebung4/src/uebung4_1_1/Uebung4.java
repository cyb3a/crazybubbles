/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uebung4_1_1;

import uebung4_1_1.MyThreadIface;
import uebung4_1_1.MyThread;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author s0558439
 */
public class Uebung4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MyThread thread1= new MyThread();
        thread1.setName("Thread 1 mit Klasse");
        thread1.setPriority(1);
        thread1.start();
        
        
        MyThreadIface thread2 = new MyThreadIface();
        Thread threadIface2 = new Thread(thread2);
        threadIface2.setName("Thread 2 mit Iface");
        threadIface2.setPriority(10);
        threadIface2.start();
        
        try {
            Thread.sleep(100);
        } catch (InterruptedException ex) {
            
        }
        thread1.interrupt();
        threadIface2.interrupt();
        
        System.out.println("ende");
    }
    
}

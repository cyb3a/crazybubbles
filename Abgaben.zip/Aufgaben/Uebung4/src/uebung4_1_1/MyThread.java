/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uebung4_1_1;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author s0558439
 */
public class MyThread extends Thread {

    public void run() {

        while (true) {
            if (isInterrupted()) {
                break;
            }
            //System.out.println("HOP");
            System.out.println(getName()+": HOP, Priorität: "+getPriority());
            
            try {

                Thread.sleep(10);
            } catch (InterruptedException ex) {
                interrupt();
            }
        }

    }

}

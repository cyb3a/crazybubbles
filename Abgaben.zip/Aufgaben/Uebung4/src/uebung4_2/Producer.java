/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uebung4_2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;
import java.util.Scanner;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author s0558439
 */
public class Producer extends Thread {

    final int MAX = 5;
    Random random = new Random();
    Vector vector;
    Scanner scanner;

    public Producer(Vector v) {
        this.vector = v;
        scanner = new Scanner(System.in);
    }

    public void run() {
        //erzeuge zufallswert und schiebe ihn ins Lager
        //for (int i = 0; i < MAX; i++) {
        while (!isInterrupted()) {
            //TODO über tastatureingabe unterbrechbar machen
            //System.out.println("<Enter> drücken zum Weiterproduzieren");
            // scanner.nextLine();
            synchronized (vector) {
                if (ProdConsProb.status == 1) {

                    int rndWert = random.nextInt(60);
                    vector.add(rndWert);
                    //kann bereits ab dem ersten wert geschehen: freigabe für den consumer
                    vector.notify();
                }
                else{
                    System.out.println("--Produzent pausiert--");
                }
            }
            try {
                Thread.sleep(500 + (int)(Math.random() * ((1000 - 500) + 1)));
            } catch (InterruptedException ex) {
                interrupt();
            }
        }
    }

}

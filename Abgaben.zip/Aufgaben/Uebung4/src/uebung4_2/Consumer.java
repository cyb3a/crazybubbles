/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uebung4_2;

import java.util.Vector;

/**
 *
 * @author s0558439
 */
public class Consumer extends Thread {

    Vector vector;

    public Consumer(Vector v) {
        this.vector = v;
    }

    public void run() {
        try {
            //producer soll die chance haben, zuerst zu laufen
            Thread.sleep(2000);
            //rufe dauernd content aus dem lager ab
            int wert = 0;
            while (!isInterrupted()) {
                synchronized (vector) {
                    if (vector.isEmpty() && ProdConsProb.status == 0) {
                        //consumer wartet, bis producer-thread mit vector.notify() den vector wieder freigibt
                        vector.wait();
                    } else {
                        System.out.println("vectorwert: " + vector.get(0));
                        //int getWert = (int)vector.get(vector.capacity());

                        int getWert = (int) vector.lastElement();
                        wert = getWert;

                        //Balkendiagramm darstellen
                        int countHilf = getWert;
                        while (countHilf > 0) {
                            for (int i = 0; i < vector.size(); i++) {
                                for (int j = 0; j < countHilf; j++) {
                                    System.out.print("*");
                                }
                                System.out.println();
                            }
                            //Thread.sleep(200);
                            countHilf--;
                        }

                        vector.removeElement(vector.lastElement());

                        System.out.println("Wert " + getWert + " aus Lager entfernt.");
                    }
                }
                Thread.sleep(1000);
                System.out.println("Wert " +wert+ " konsumiert.");

            }
        } catch (InterruptedException e) {
            interrupt();
        }
    }

}

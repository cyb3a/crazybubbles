/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uebung4_2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Vector;

/**
 *
 * @author s0558439
 */
public class ProdConsProb {

    static int status = 1;
    static boolean ok = true;

    public static void main(String[] args) throws IOException {
        //Folie 45ff
        Vector vector = new Vector();

        Consumer c = new Consumer(vector);
        Producer p = new Producer(vector);

        p.start();

        c.start();

        while (ok) {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            char eingabe = (char) br.read();
            switch (eingabe) {
                case 'p': //pause
                    status = 0;
                    break;

                case 'c': //continue
                    status = 1;
                    break;

                case 'e':
                    p.interrupt();
                    c.interrupt();
                    ok = false;
                    System.out.println("Programmende");
                    break;
            }
        }
    }
}

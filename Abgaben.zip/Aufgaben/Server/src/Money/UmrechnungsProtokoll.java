/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Money;

/**
 *
 * @author tabea
 */
public class UmrechnungsProtokoll {

    private State state = State.WAITING;
    private String currency = "";
    private float moneyAmount = 0;

    public String processInput(String theInput) {
        String theOutput = "";

        if (state == state.WAITING) {
            theOutput = "Welche Währung wollen Sie eingeben (DM oder EURO)?";
            state = State.SENT_CURRENCY_QUESTION;
        } else if (state == state.SENT_CURRENCY_QUESTION) {
            if (theInput.equals("DM") || theInput.equals("EURO")) {
                currency = theInput;
                theOutput = "Welchen Wert wollen Sie umrechnen?";
                state = State.SENT_MONEY_QUESTION;
            }
            else {
                theOutput= "keine gueltige Eingabe, nochmal:";
            }
        } else if (state == State.SENT_MONEY_QUESTION) {
            moneyAmount = Float.valueOf(theInput);
            float converted = 0;
            if (currency.equals("DM")) {
                converted = moneyAmount / 1.95583f;
                theOutput = "umgerechnet: " + converted + " EURO";
            }
            if (currency.equals("EURO")) {
                converted = moneyAmount * 1.95583f;
                theOutput = "umgerechnet: " + converted + " DM";
            }
            state = State.SENT_COMPUTED_VALUE;
        } else if (state == State.SENT_COMPUTED_VALUE) {
            theOutput = "Noch einen Wert umrechnen? (j/n)";
            state = State.ANOTHER;
        } else if (state == State.ANOTHER) {
            if (theInput.equals("j")) {
                theOutput = "Welche Währung wollen Sie eingeben (DM oder EURO)?";
                state = State.SENT_CURRENCY_QUESTION;
            } else {
                theOutput = "Bye";
                state = State.WAITING;
            }
        }
        return theOutput;
    }

}

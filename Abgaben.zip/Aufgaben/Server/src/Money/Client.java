/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Money;

import Prog1Tools.IOTools;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.io.PrintWriter;
import java.util.Arrays;
/**
 *
 * @author tabea
 */
public class Client {

    public static void main(String[] args) {
        try (Socket clientSocket = new Socket("127.0.0.1", 44444)) {
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(),true);
            
            String toServer, fromServer;
            
            System.out.println("Der Client läuft und kann mit 'quit' beendet werden.");
            
            while((fromServer=in.readLine())!=null){
                System.out.println(fromServer);
                
                toServer = IOTools.readLine();
                if(toServer!=null){
                    out.println(toServer);
                }
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

}

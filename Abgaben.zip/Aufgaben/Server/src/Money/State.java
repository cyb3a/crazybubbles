/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Money;

/**
 *
 * @author tabea
 */
public enum State {
    WAITING,
    SENT_CURRENCY_QUESTION,
    SENT_MONEY_QUESTION,
    SENT_COMPUTED_VALUE,
    ANOTHER
}

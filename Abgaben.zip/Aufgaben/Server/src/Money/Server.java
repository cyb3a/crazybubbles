/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Money;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author tabea
 */
public class Server {

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(44444)) {
            Socket clientSocket = serverSocket.accept();
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

            String inputLine, outputLine;
            System.out.println("Server gestartet und bereit. ");

            //Erste Nachricht an Client
            UmrechnungsProtokoll uprot = new UmrechnungsProtokoll();
            outputLine = uprot.processInput(null);
            out.println(outputLine);

            while ((inputLine = in.readLine()) != null) {
                if(inputLine.equals("quit")){
                    break;
                }
                outputLine = uprot.processInput(inputLine);
                out.println(outputLine);
                if (outputLine.equals("Bye")) {
                    break;
                }
            }

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
